<?php

namespace app\controllers;

use app\models\Info;
use Yii;
use yii\filters\AccessControl;
use yii\web\Controller;
use yii\filters\VerbFilter;
use yii\web\MethodNotAllowedHttpException;

class SiteController extends Controller
{

    /**
     * {@inheritdoc}
     */
    public function actions()
    {
        return [
            'error' => [
                'class' => 'yii\web\ErrorAction',
            ]
        ];
    }


    public function actionIndex()
    {

        return $this->render('index');
    }

    public function actionInfo($iin){
        \Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
        if(Yii::$app->request->isAjax){
            $info = new Info();
            return $info->getClientInfo($iin);
        }
        throw new MethodNotAllowedHttpException('405');
    }


    public function actionSaveData(){
        \Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
        if(Yii::$app->request->isAjax){
            if(Yii::$app->request->isPost){
                return [
                    'status' => 'success',
                    'data' =>  Yii::$app->request->post()
                ];
            }
        }
        throw new MethodNotAllowedHttpException('405');
    }



}
